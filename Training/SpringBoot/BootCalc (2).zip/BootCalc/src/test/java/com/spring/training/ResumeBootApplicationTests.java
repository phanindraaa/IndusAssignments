package com.spring.training;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResumeBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
