package com.spring.training;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.indus.training.core.impl.CalcEncr;
import com.indus.training.core.domain.CalcEncInp;
import com.indus.training.core.domain.CalcEncOut;

import java.io.IOException;

@Configuration
public class ServletConfig {

    @Bean
    public ServletRegistrationBean<CalculatorServlet> calculatorServlet() {
        return new ServletRegistrationBean<>(new CalculatorServlet(), "/calculate");
    }
}

class CalculatorServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        resp.getWriter().write(
            "<html><body>" +
            "<h1>Calculator Servlet</h1>" +
            "<form method='post'>" +
            "Number 1: <input type='number' name='num1' required><br>" +
            "Number 2: <input type='number' name='num2' required><br>" +
            "Operation: " +
            "<select name='operation'>" +
            "<option value='add'>Add</option>" +
            "<option value='subtract'>Subtract</option>" +
            "<option value='multiply'>Multiply</option>" +
            "<option value='divide'>Divide</option>" +
            "</select><br>" +
            "<input type='submit' value='Calculate'>" +
            "</form>" +
            "</body></html>"
        );
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        double num1 = Double.parseDouble(req.getParameter("num1"));
        double num2 = Double.parseDouble(req.getParameter("num2"));
        String operation = req.getParameter("operation");

        CalcEncr calculator = new CalcEncr();
        CalcEncInp input = new CalcEncInp();
        input.setPraam1(num1);
        input.setPraam2(num2);

        CalcEncOut result;

        switch (operation) {
            case "add":
                result = calculator.Addition(input);
                break;
            case "subtract":
                result = calculator.Subtract(input);
                break;
            case "multiply":
                result = calculator.Multiply(input);
                break;
            case "divide":
                result = calculator.Division(input);
                break;
            default:
                result = new CalcEncOut();
                result.setResult(num2);
        }

        resp.setContentType("text/html");
        resp.getWriter().write(
            "<html><body>" +
            "<h1>Result</h1>" +
            "<p>The result is: " + result.getResult() + "</p>" +
            "<a href='/calculate'>Back to Calculator</a>" +
            "</body></html>"
        );
    }
}