package com.indus.training.core.impl;

import java.util.Arrays;

import com.indus.training.core.svc.IContacts;

public class ContactsList implements IContacts {

	static String[] contactsArray;
	public int initialSize;
	int contactCount = 0;
	public int remaining;

	public ContactsList(int initialSize) {
		contactsArray = new String[initialSize];
		this.initialSize = initialSize;
		this.remaining = initialSize;
	}

	// Implementing the addContacts method from IContactsList
	@Override
	public void addContacts(String[] newContacts) {
		try {
			int number = newContacts.length;

			// Check if the array needs resizing
			if (number > remaining) {
				// Resize the array and copy existing elements
				String[] newArr = new String[contactCount + number];
				System.arraycopy(contactsArray, 0, newArr, 0, contactsArray.length);
				contactsArray = newArr;
				remaining = number;
			}

			// Add new contacts to the array
			for (int i = 0; i < number; i++) {
				contactsArray[contactCount] = newContacts[i];
				contactCount++;
			}
			remaining -= number; // Update remaining space

		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Error: Attempted to access array outside of its bounds.");
		}
	}

	// Implementing the sortContacts method from IContactsList
	@Override
	public void sortContacts() {
		try {
			Arrays.sort(contactsArray, 0, contactCount); // Sort only the filled portion of the array
		} catch (Exception e) {
			System.out.println("Error while sorting the contacts: " + e.getMessage());
		}
	}

	// Implementing the getContacts method from IContactsList
	@Override
	public String getContacts() {
		return Arrays.toString(Arrays.copyOfRange(contactsArray, 0, contactCount));
	}

	// Implementing the getContactsArraySize method from IContactsList
	@Override
	public int getContactsArraySize() {
		return contactsArray.length;
	}

	// Main method for demonstration
	public static void main(String[] args) {
		try {
			ContactsList contacts = new ContactsList(5);
			contacts.addContacts(new String[] { "Ravi", "Sita", "Raju", "Lakshmi" });
			contacts.addContacts(new String[] { "Krishna", "Gopal", "Vas", "Anjali" });
			contacts.addContacts(new String[] { "Manjula", "Venkat" });
			System.out.println("Contacts: " + contacts.getContacts());
			contacts.sortContacts();
			System.out.println("Sorted Contacts: " + contacts.getContacts());
		} catch (Exception e) {
			System.out.println("An error occurred: " + e.getMessage());
		}
	}

}
