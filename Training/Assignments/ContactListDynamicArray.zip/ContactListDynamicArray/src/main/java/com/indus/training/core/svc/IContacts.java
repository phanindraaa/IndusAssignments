package com.indus.training.core.svc;

public interface IContacts {
	
    public void addContacts(String[] newContacts);
    
    public void sortContacts();
    
    public String getContacts();
    
    public int getContactsArraySize();
}
