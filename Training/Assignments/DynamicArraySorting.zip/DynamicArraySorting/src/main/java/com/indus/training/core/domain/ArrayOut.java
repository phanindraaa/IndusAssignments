package com.indus.training.core.domain;

public class ArrayOut {

}
