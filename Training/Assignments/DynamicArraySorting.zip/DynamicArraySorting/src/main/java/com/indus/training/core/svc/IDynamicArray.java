package com.indus.training.core.svc;

public interface IDynamicArray {
	public void dynamicAlloc(double Value) throws ArrayIndexOutOfBoundsException;
	public void ArraySorting();
	
}
