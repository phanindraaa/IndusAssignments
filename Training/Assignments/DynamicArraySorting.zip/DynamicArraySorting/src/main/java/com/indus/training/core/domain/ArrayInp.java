package com.indus.training.core.domain;

public class ArrayInp {
	private static double[] FinalArray;
	private static int Count;
}
