package com.indus.training.core.domain;

public class CalcEncInp {

	private double param1;
	private double param2;
	
	public void setPraam1(double d) {
		param1 = d;
	}
	
	public double getParam1() {
		return param1;
	}
	
	public void setPraam2(double d) {
		param2 = d;
	}
	
	public double getParam2() {
		return param2;
	}
}

