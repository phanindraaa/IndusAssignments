package com.indus.training.spring.entity;

public class Response {
    private String htmlResponse;

    public Response() {
        this.htmlResponse = "";
    }

    public void setHtmlResponse(String htmlResponse) {
        this.htmlResponse = htmlResponse;
    }

    public String getHtmlResponse() {
        return htmlResponse;
    }
}
