package com.indus.training.spring.entity;

public class CalcOutput {	
	private double param1;
	private double param2;
	private double result;
	public double getParam1() {
		return param1;
	}
	public void setParam1(double param1) {
		this.param1 = param1;
	}
	public double getParam2() {
		return param2;
	}
	public void setParam2(double param2) {
		this.param2 = param2;
	}
	public double getResult() {
		return result;
	}
	public void setResult(double result) {
		this.result = result;
	}

}
