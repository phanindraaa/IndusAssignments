package com.indus.training.spring.entity;

public class CalcInput {
	private int param1;
	private int param2;
	public CalcInput(int i, int j) {
		this.param1 = i;
		this.param2 = j;
		// TODO Auto-generated constructor stub
	}
	public int getParam1() {
		return param1;
	}
	
	public int getParam2() {
		return param2;
	}
	
}
