package com.indus.training.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.indus.training.spring.entity.CalcInput;
import com.indus.training.spring.entity.CalcOutput;
import com.indus.training.spring.svc.CalculatorService;

@RestController
public class CalculatorController {

    @Autowired
    private CalculatorService calculatorService;

    @PostMapping("/add")
    public CalcOutput add(@RequestBody CalcInput input) {
        return calculatorService.add(input);
    }

    @PostMapping("/subtract")
    public CalcOutput subtract(@RequestBody CalcInput input) {
        return calculatorService.subtract(input);
    }

    @PostMapping("/multiply")
    public CalcOutput multiply(@RequestBody CalcInput input) {
        return calculatorService.multiply(input);
    }

    @PostMapping("/divide")
    public CalcOutput divide(@RequestBody CalcInput input) {
        return calculatorService.divide(input);
    }
}
